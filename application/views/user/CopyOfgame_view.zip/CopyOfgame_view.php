<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="<?php echo base_url();?>styles/memory_game.css" type="text/css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/game/jquery.metadata.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/game/jquery.quickflip.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/game/memory_game.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/game/swfobject.js"></script>
<title>Insert title here</title>
<script type="text/javascript">
	var flashvars = false;
	var attributes = {};
	var params = {
	  allowscriptaccess : "always",
	  wmode : "transparent",
	  menu: "false"
	};
	swfobject.embedSWF("<?php echo base_url();?>js/game/sfx.swf", "sfx_movie", "1", "1", "9.0.0", "<?php echo base_url();?>js/game/expressInstall.swf", flashvars, params, attributes);
</script>
<style>
	<?php 
		print $board->get_css();
	?>
</style>
</head>


<body>
	<h3>Simple Memory Game</h3>
<div id="sfx_movie">
	<h1>This page requires flash for full funcionality</h1>
	<p><a href="http://www.adobe.com/go/getflashplayer">
		<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" />
	</a></p>
</div>
<div id="control" style="width:<?php print $board->get_cols()*75; ?>px;">
	<label>Level:</label>
	<select id="level_chooser">
		<?php 
			print "<!-- ".$board->max_level()." -->";
			for ( $i = 0; $i < $board->max_level(); ++$i ){
					$selected = ( ($i+1) == $level ) ? " selected=selected" : "";
					print "\r<option value=\"".($i+1)."\"".$selected.">".($i+1)."</option>";
			}
		?>
		
	</select>
	<label>Games Finished: </label>
	<span><?php print $_SESSION["games_won"]; ?></span>
	<label>Moves:</label>
	<span id="num_of_moves">0</span>
</div>
<div id="game_board" style="width:<?php print $board->get_cols()*75; ?>px;">
<?php
	print $board->get_html();
?>
</div>
<div id="player_won"></div>
<div id="start_again"><a id="again" href="#">Click here to play again</a></div>
<div id="sfx_movie">
	<h1>This page requires flash for full funcionality</h1>
	<p><a href="http://www.adobe.com/go/getflashplayer">
		<img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" />
	</a></p>
</div>

</body>
</html>